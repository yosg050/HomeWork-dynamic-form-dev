import { Suspense } from "react";
import Container from "@mui/material/Container";
import { Alert, CircularProgress } from "@mui/material";
import { useAnalytics } from "../queries/analytics";

function AnalyticsContent() {
  const { data, isLoading, error } = useAnalytics();
  console.log("data: " ,data);
  
  if (isLoading) {
    return (
      <Container sx={{ py: 4, textAlign: "center" }}>
        <CircularProgress />
      </Container>
    );
  }
  if (error) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert severity="error">Failed to load analytics</Alert>
      </Container>
    );
  }
  const a = data || {};
  const total = a.totalSubmissions ?? 0;
  const avgAge = a.averageAgeYears ?? "-";
  const lastAt = a.derived?.lastSubmissionAt;
  const agesCounted = a.derived?.agesCounted ?? 0;

  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" sx={{ mb: 3 }} align="center">
        Analytics
      </Typography>

      <Grid container spacing={2}>
        <Grid item xs={12} md={3}>
          <StatCard label="Total Submissions" value={total} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard
            label="Average Age (yrs)"
            value={avgAge}
            helper={`Ages counted: ${agesCounted}`}
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard label="Last Submission" value={fmtDate(lastAt)} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard
            label="Distinct Genders"
            value={Object.keys(a.perGender || {}).length}
          />
        </Grid>

        <Grid item xs={12} md={6}>
          <AnalyticsGender perGender={a.perGender} />
        </Grid>
        <Grid item xs={12} md={6}>
          <AnalyticsAgeBuckets ageBuckets={a.derived?.ageBuckets || {}} />
        </Grid>
      </Grid>

      {total === 0 && (
        <Alert severity="info" sx={{ mt: 3 }}>
          No data yet, submit a form first to see analytics.{" "}
        </Alert>
      )}
    </Container>
  );
}

export default function AnalyticsPage() {
  return (
    <Suspense
      fallback={
        <Container sx={{ py: 4, textAlign: "center" }}>
          <CircularProgress />
        </Container>
      }
    >
      <AnalyticsContent />
    </Suspense>
  );
}