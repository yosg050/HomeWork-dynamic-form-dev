    
export async function getAnalytics() {
  const res = await apiFetch("/analytics", { method: "GET" });
  const data = await res.json();
  return data.items ?? [];
}